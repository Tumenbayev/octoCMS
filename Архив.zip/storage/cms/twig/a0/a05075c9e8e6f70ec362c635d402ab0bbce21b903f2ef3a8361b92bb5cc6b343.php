<?php

/* /home/vagrant/Code/octoCMS/themes/multi/pages/otzyvy.htm */
class __TwigTemplate_c0cd814c98ca406b8886b06b32d082ea95bc7090197ed483fba55123483d692b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "/home/vagrant/Code/octoCMS/themes/multi/pages/otzyvy.htm";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/home/vagrant/Code/octoCMS/themes/multi/pages/otzyvy.htm", "");
    }
}
