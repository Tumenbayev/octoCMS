<?php

/* /home/vagrant/Code/octoCMS/themes/multi/partials/faqs.htm */
class __TwigTemplate_5060c482743fb9a0bfbd5e1624e8e07559b995ff23ec03d58432e537e57324b4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<ul style=\"list-style:none;\">
\t";
        // line 2
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["faq"] ?? null), "getFaqs", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 3
            echo "\t<li>
\t\t<div class=\"panel panel-default\">
\t\t\t<div class=\"panel-heading\">
\t\t\t\t<strong>";
            // line 6
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "name", array()), "html", null, true);
            echo "</strong> <span class=\"text-muted\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "created_at", array()), "html", null, true);
            echo "</span>
\t\t\t</div>
\t\t\t<div class=\"panel-body\">
\t\t\t\t";
            // line 9
            echo $this->getAttribute($context["item"], "comment", array());
            echo "
\t\t\t</div><!-- /panel-body -->
\t\t</div><!-- /panel panel-default -->
\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 13
        echo "\t</li>
</ul>";
    }

    public function getTemplateName()
    {
        return "/home/vagrant/Code/octoCMS/themes/multi/partials/faqs.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 13,  39 => 9,  31 => 6,  26 => 3,  22 => 2,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<ul style=\"list-style:none;\">
\t{% for item in faq.getFaqs %}
\t<li>
\t\t<div class=\"panel panel-default\">
\t\t\t<div class=\"panel-heading\">
\t\t\t\t<strong>{{item.name}}</strong> <span class=\"text-muted\">{{item.created_at}}</span>
\t\t\t</div>
\t\t\t<div class=\"panel-body\">
\t\t\t\t{{item.comment | raw}}
\t\t\t</div><!-- /panel-body -->
\t\t</div><!-- /panel panel-default -->
\t\t{% endfor %}
\t</li>
</ul>", "/home/vagrant/Code/octoCMS/themes/multi/partials/faqs.htm", "");
    }
}
