<?php

/* /home/vagrant/Code/octoCMS/themes/multi/partials/team.htm */
class __TwigTemplate_d57ae76e7675fde27c06f71be317bffd4ff486ad4857d92011349ac45541eb8e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"container\">
            <div class=\"section-header\">
                <h2 class=\"section-title text-center wow fadeInDown\">Наши мастера</h2>
                <p class=\"text-center wow fadeInDown\">Наши мастера помогут Вам достичь немысленных результатов за кратчайшие сроки!</p>
            </div>

            <div class=\"row\">
                ";
        // line 8
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["team"] ?? null), "getTeam", array()));
        foreach ($context['_seq'] as $context["key"] => $context["item"]) {
            // line 9
            echo "                    <div class=\"col-sm-6 col-md-3\">
                        <div class=\"team-member wow fadeInUp\" data-wow-duration=\"400ms\" data-wow-delay=\"0ms\">
                            <div class=\"team-img\">
                                <img class=\"img-responsive\" src=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "attachments", array()), "path", array()), "html", null, true);
            echo "\" alt=\"\">
                            </div>
                            <div class=\"team-info\">
                                <h3>";
            // line 15
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "name", array()), "html", null, true);
            echo "</h3>
                                <span>";
            // line 16
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "position", array()), "html", null, true);
            echo "</span>
                            </div>
                            ";
            // line 18
            echo $this->getAttribute($context["item"], "description", array());
            echo "
                        </div>
                    </div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 22
        echo "            </div>

        </div>";
    }

    public function getTemplateName()
    {
        return "/home/vagrant/Code/octoCMS/themes/multi/partials/team.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  62 => 22,  52 => 18,  47 => 16,  43 => 15,  37 => 12,  32 => 9,  28 => 8,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"container\">
            <div class=\"section-header\">
                <h2 class=\"section-title text-center wow fadeInDown\">Наши мастера</h2>
                <p class=\"text-center wow fadeInDown\">Наши мастера помогут Вам достичь немысленных результатов за кратчайшие сроки!</p>
            </div>

            <div class=\"row\">
                {% for key, item in team.getTeam %}
                    <div class=\"col-sm-6 col-md-3\">
                        <div class=\"team-member wow fadeInUp\" data-wow-duration=\"400ms\" data-wow-delay=\"0ms\">
                            <div class=\"team-img\">
                                <img class=\"img-responsive\" src=\"{{ item.attachments.path }}\" alt=\"\">
                            </div>
                            <div class=\"team-info\">
                                <h3>{{item.name}}</h3>
                                <span>{{item.position}}</span>
                            </div>
                            {{item.description | raw}}
                        </div>
                    </div>
                {% endfor %}
            </div>

        </div>", "/home/vagrant/Code/octoCMS/themes/multi/partials/team.htm", "");
    }
}
