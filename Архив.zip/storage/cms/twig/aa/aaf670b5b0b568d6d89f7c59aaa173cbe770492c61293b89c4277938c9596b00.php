<?php

/* /home/vagrant/Code/octoCMS/themes/multi/partials/cta.htm */
class __TwigTemplate_e4ecf78548ced94540a73f5ca8a840aa6e4102e660a2a9b96432db61fe800e08 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h2 class=\"wow fadeInUp\" data-wow-duration=\"300ms\" data-wow-delay=\"0ms\"><span>BeautyMed</span></h2>
                <p class=\"wow fadeInUp\" data-wow-duration=\"300ms\" data-wow-delay=\"100ms\">Это новая современная клиника в г. Уральске, объединяющая сразу в себе два направления дерматокосметология и дерматовенерология.<br/>
                BeautyMed - клиника, где могут получить квалифицированную помощь люди с дерматовенерологическими заболеваниями, а также первая в Западно - Казахстанской области лицензированная дерматокосметологическая клиника.я
                </p>
                <p class=\"wow fadeInUp\" data-wow-duration=\"300ms\" data-wow-delay=\"200ms\">
\t                <center>
\t                \t<a class=\"btn btn-primary btn-lg\" data-toggle=\"modal\"  href=\"#callToAction\">Заказать звонок?</a>
\t                </center>
                </p>
                <img class=\"img-responsive wow fadeIn\" src=\"";
        // line 10
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/cta2/cta2-img.png");
        echo "\" alt=\"\" data-wow-duration=\"300ms\" data-wow-delay=\"300ms\">

\t\t\t\t<div class=\"control-popup modal fade\" id=\"callToAction\" tabindex=\"-1\" role=\"dialog\">
\t\t\t\t    <div class=\"modal-dialog\">
\t\t\t\t        <div class=\"modal-content\">
\t\t\t\t            <div class=\"modal-header\">
\t\t\t\t                <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>
\t\t\t\t                <h4 class=\"modal-title\">Хотите чтобы, мы Вам перезвонили?</h4>
\t\t\t\t            </div>
\t\t\t                <form data-request=\"onEmailSend\" data-request-update=\"'result': '#result'\">
\t\t\t\t\t            <div class=\"modal-body\">
\t\t\t\t\t            \t<div class=\"form-group\">
\t\t\t\t\t                \t<input type=\"text\" name=\"name\" class=\"form-control\" required placeholder=\"Ваше имя\"/>
\t\t\t\t\t                </div>
\t\t\t\t\t                <div class=\"form-group\">
\t\t\t\t\t                \t<input type=\"text\" name=\"phoneNum\" class=\"form-control\" required placeholder=\"Ваш номер телефона\"/>
\t\t\t\t\t                </div>
\t\t\t\t\t                \t<div id=\"result\">";
        // line 27
        echo twig_escape_filter($this->env, ($context["result"] ?? null), "html", null, true);
        echo "</div>
\t\t\t\t\t            </div>
\t\t\t\t\t            <div class=\"modal-footer\">
\t\t\t\t\t                <button type=\"button\" class=\"btn btn-warning\" data-dismiss=\"modal\">Отменить</button>
\t\t\t\t\t                <button type=\"submit\" class=\"btn btn-primary\">Отправить</button>
\t\t\t\t\t            </div>
\t\t\t\t            </form>
\t\t\t\t        </div>
\t\t\t\t    </div>
\t\t\t\t</div>";
    }

    public function getTemplateName()
    {
        return "/home/vagrant/Code/octoCMS/themes/multi/partials/cta.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  50 => 27,  30 => 10,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<h2 class=\"wow fadeInUp\" data-wow-duration=\"300ms\" data-wow-delay=\"0ms\"><span>BeautyMed</span></h2>
                <p class=\"wow fadeInUp\" data-wow-duration=\"300ms\" data-wow-delay=\"100ms\">Это новая современная клиника в г. Уральске, объединяющая сразу в себе два направления дерматокосметология и дерматовенерология.<br/>
                BeautyMed - клиника, где могут получить квалифицированную помощь люди с дерматовенерологическими заболеваниями, а также первая в Западно - Казахстанской области лицензированная дерматокосметологическая клиника.я
                </p>
                <p class=\"wow fadeInUp\" data-wow-duration=\"300ms\" data-wow-delay=\"200ms\">
\t                <center>
\t                \t<a class=\"btn btn-primary btn-lg\" data-toggle=\"modal\"  href=\"#callToAction\">Заказать звонок?</a>
\t                </center>
                </p>
                <img class=\"img-responsive wow fadeIn\" src=\"{{ 'assets/images/cta2/cta2-img.png'|theme }}\" alt=\"\" data-wow-duration=\"300ms\" data-wow-delay=\"300ms\">

\t\t\t\t<div class=\"control-popup modal fade\" id=\"callToAction\" tabindex=\"-1\" role=\"dialog\">
\t\t\t\t    <div class=\"modal-dialog\">
\t\t\t\t        <div class=\"modal-content\">
\t\t\t\t            <div class=\"modal-header\">
\t\t\t\t                <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>
\t\t\t\t                <h4 class=\"modal-title\">Хотите чтобы, мы Вам перезвонили?</h4>
\t\t\t\t            </div>
\t\t\t                <form data-request=\"onEmailSend\" data-request-update=\"'result': '#result'\">
\t\t\t\t\t            <div class=\"modal-body\">
\t\t\t\t\t            \t<div class=\"form-group\">
\t\t\t\t\t                \t<input type=\"text\" name=\"name\" class=\"form-control\" required placeholder=\"Ваше имя\"/>
\t\t\t\t\t                </div>
\t\t\t\t\t                <div class=\"form-group\">
\t\t\t\t\t                \t<input type=\"text\" name=\"phoneNum\" class=\"form-control\" required placeholder=\"Ваш номер телефона\"/>
\t\t\t\t\t                </div>
\t\t\t\t\t                \t<div id=\"result\">{{ result }}</div>
\t\t\t\t\t            </div>
\t\t\t\t\t            <div class=\"modal-footer\">
\t\t\t\t\t                <button type=\"button\" class=\"btn btn-warning\" data-dismiss=\"modal\">Отменить</button>
\t\t\t\t\t                <button type=\"submit\" class=\"btn btn-primary\">Отправить</button>
\t\t\t\t\t            </div>
\t\t\t\t            </form>
\t\t\t\t        </div>
\t\t\t\t    </div>
\t\t\t\t</div>", "/home/vagrant/Code/octoCMS/themes/multi/partials/cta.htm", "");
    }
}
