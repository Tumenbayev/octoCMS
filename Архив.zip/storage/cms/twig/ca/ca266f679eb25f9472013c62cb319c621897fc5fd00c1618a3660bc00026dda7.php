<?php

/* /home/vagrant/Code/octoCMS/themes/multi/partials/about.htm */
class __TwigTemplate_f99a1b1d3765a3e87e7d0426f863a20ecc07e6d5103418449d1197021bddb511 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"container\">

            <div class=\"section-header\">
                <h2 class=\"section-title text-center wow fadeInDown\">Врач - косметолог, дерматовенеролог в Уральске</h2>
            </div>

            <div class=\"row\">
                <div class=\"col-sm-10 col-sm-offset-1\">
                    <div class=\"col-sm-6 wow fadeInLeft\">
                        ";
        // line 10
        $context['__cms_content_params'] = [];
        echo $this->env->getExtension('CMS')->contentFunction("about/video.htm"        , $context['__cms_content_params']        );
        unset($context['__cms_content_params']);
        // line 11
        echo "                    </div>

                    <div class=\"col-sm-6 wow fadeInRight\">
                        ";
        // line 14
        $context['__cms_content_params'] = [];
        echo $this->env->getExtension('CMS')->contentFunction("about/capabilities.htm"        , $context['__cms_content_params']        );
        unset($context['__cms_content_params']);
        // line 15
        echo "                    </div>
                </div>
            </div>
            <div class=\"row\">
                <div class=\"col-sm-10 col-sm-offset-1\">
                    <div class=\"col-sm-6 wow fadeInLeft\">
                        ";
        // line 21
        $context['__cms_content_params'] = [];
        echo $this->env->getExtension('CMS')->contentFunction("about/capabilities2.htm"        , $context['__cms_content_params']        );
        unset($context['__cms_content_params']);
        // line 22
        echo "                    </div>

                    <div class=\"col-sm-6 wow fadeInRight\">
                        ";
        // line 25
        $context['__cms_content_params'] = [];
        echo $this->env->getExtension('CMS')->contentFunction("about/video2.htm"        , $context['__cms_content_params']        );
        unset($context['__cms_content_params']);
        // line 26
        echo "                    </div>
                </div>
            </div>";
    }

    public function getTemplateName()
    {
        return "/home/vagrant/Code/octoCMS/themes/multi/partials/about.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  64 => 26,  60 => 25,  55 => 22,  51 => 21,  43 => 15,  39 => 14,  34 => 11,  30 => 10,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"container\">

            <div class=\"section-header\">
                <h2 class=\"section-title text-center wow fadeInDown\">Врач - косметолог, дерматовенеролог в Уральске</h2>
            </div>

            <div class=\"row\">
                <div class=\"col-sm-10 col-sm-offset-1\">
                    <div class=\"col-sm-6 wow fadeInLeft\">
                        {% content 'about/video.htm' %}
                    </div>

                    <div class=\"col-sm-6 wow fadeInRight\">
                        {% content 'about/capabilities.htm' %}
                    </div>
                </div>
            </div>
            <div class=\"row\">
                <div class=\"col-sm-10 col-sm-offset-1\">
                    <div class=\"col-sm-6 wow fadeInLeft\">
                        {% content 'about/capabilities2.htm' %}
                    </div>

                    <div class=\"col-sm-6 wow fadeInRight\">
                        {% content 'about/video2.htm' %}
                    </div>
                </div>
            </div>", "/home/vagrant/Code/octoCMS/themes/multi/partials/about.htm", "");
    }
}
