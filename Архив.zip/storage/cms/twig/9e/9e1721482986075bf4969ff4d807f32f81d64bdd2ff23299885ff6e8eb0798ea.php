<?php

/* /home/vagrant/Code/octoCMS/themes/multi/partials/portfolio.htm */
class __TwigTemplate_1da8d6f05f924387bf0c0f6fda8c71c2aa1a2ccc7ece098b460fafe71840c740 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"container\">
            <div class=\"section-header\">
                <h2 class=\"section-title text-center wow fadeInDown\">Лицензии и сертификаты</h2>
                <p class=\"text-center wow fadeInDown\">Мы работаем на рынке красоты не первый год и имеем список достижении и подтверждении навыков.</p>
            </div>

            <div class=\"portfolio-items\">
              ";
        // line 8
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["certs"] ?? null));
        foreach ($context['_seq'] as $context["key"] => $context["cert"]) {
            // line 9
            echo "              <div class=\"portfolio-item\">
                  <div class=\"portfolio-item-inner\">
                      <img class=\"img-responsive\" src=\"";
            // line 11
            echo twig_escape_filter($this->env, $context["cert"], "html", null, true);
            echo "\" alt=\"\" style=\"height:350px;\">
                      <div class=\"portfolio-info\">
                          <h3>Сертификат ";
            // line 13
            echo twig_escape_filter($this->env, ($context["key"] + 1), "html", null, true);
            echo "</h3>
                          <a class=\"preview\" href=\"";
            // line 14
            echo twig_escape_filter($this->env, $context["cert"], "html", null, true);
            echo "\" rel=\"prettyPhoto\"><i class=\"fa fa-eye\"></i></a>
                      </div>
                  </div>
              </div><!--/.portfolio-item-->
              ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['cert'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 19
        echo "            </div>
        </div><!--/.container-->";
    }

    public function getTemplateName()
    {
        return "/home/vagrant/Code/octoCMS/themes/multi/partials/portfolio.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  56 => 19,  45 => 14,  41 => 13,  36 => 11,  32 => 9,  28 => 8,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"container\">
            <div class=\"section-header\">
                <h2 class=\"section-title text-center wow fadeInDown\">Лицензии и сертификаты</h2>
                <p class=\"text-center wow fadeInDown\">Мы работаем на рынке красоты не первый год и имеем список достижении и подтверждении навыков.</p>
            </div>

            <div class=\"portfolio-items\">
              {% for key, cert in certs %}
              <div class=\"portfolio-item\">
                  <div class=\"portfolio-item-inner\">
                      <img class=\"img-responsive\" src=\"{{cert}}\" alt=\"\" style=\"height:350px;\">
                      <div class=\"portfolio-info\">
                          <h3>Сертификат {{key+1}}</h3>
                          <a class=\"preview\" href=\"{{cert}}\" rel=\"prettyPhoto\"><i class=\"fa fa-eye\"></i></a>
                      </div>
                  </div>
              </div><!--/.portfolio-item-->
              {% endfor %}
            </div>
        </div><!--/.container-->", "/home/vagrant/Code/octoCMS/themes/multi/partials/portfolio.htm", "");
    }
}
