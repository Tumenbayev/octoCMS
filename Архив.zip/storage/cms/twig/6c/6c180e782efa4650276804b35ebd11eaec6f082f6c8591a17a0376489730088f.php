<?php

/* /home/vagrant/Code/octoCMS/themes/multi/partials/services2.htm */
class __TwigTemplate_9831de8ddb6615ba1ff057721574ef20d5bd76555345d0c6c796f92d61ba6af8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"container\">
            <div class=\"section-header\">
                <h2 class=\"section-title text-center wow fadeInDown\">Услуги</h2>
                <p class=\"text-center wow fadeInDown\">Компания BeautyAndSpa представляет большой спектр услуг по тому, что делают салоны красоты.</p>
            </div>

            <div class=\"row\">
                <div class=\"features\">
                ";
        // line 9
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["post"] ?? null), "getBeautySpaPosts", array()));
        foreach ($context['_seq'] as $context["key"] => $context["item"]) {
            // line 10
            echo "                    <div class=\"col-md-3 col-sm-6 wow fadeInUp\" data-wow-duration=\"300ms\" data-wow-delay=\"0ms\">
                        <div class=\"media service-box\">
                            <div class=\"pull-left\">
                                <img src=\"https://placeholdit.imgix.net/~text?txtsize=10&bg=b945d6&txtclr=ffffff&txt=";
            // line 13
            echo twig_escape_filter($this->env, ($context["key"] + 1), "html", null, true);
            echo "&w=32&h=32\" style=\"border-radius:10px;\">
                            </div>
                            <div class=\"media-body\" style=\"padding-top: 5px;\">
                                <h4 class=\"media-heading\"><a href=\"";
            // line 16
            echo url("/", $this->getAttribute($context["item"], "slug", array()));
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "title", array()), "html", null, true);
            echo "</a></h4>
                            </div>
                        </div>
                    </div><!--/.col-md-4-->
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 21
        echo "                </div>
            </div><!--/.row-->
        </div><!--/.container-->";
    }

    public function getTemplateName()
    {
        return "/home/vagrant/Code/octoCMS/themes/multi/partials/services2.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 21,  44 => 16,  38 => 13,  33 => 10,  29 => 9,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"container\">
            <div class=\"section-header\">
                <h2 class=\"section-title text-center wow fadeInDown\">Услуги</h2>
                <p class=\"text-center wow fadeInDown\">Компания BeautyAndSpa представляет большой спектр услуг по тому, что делают салоны красоты.</p>
            </div>

            <div class=\"row\">
                <div class=\"features\">
                {% for key, item in post.getBeautySpaPosts %}
                    <div class=\"col-md-3 col-sm-6 wow fadeInUp\" data-wow-duration=\"300ms\" data-wow-delay=\"0ms\">
                        <div class=\"media service-box\">
                            <div class=\"pull-left\">
                                <img src=\"https://placeholdit.imgix.net/~text?txtsize=10&bg=b945d6&txtclr=ffffff&txt={{key+1}}&w=32&h=32\" style=\"border-radius:10px;\">
                            </div>
                            <div class=\"media-body\" style=\"padding-top: 5px;\">
                                <h4 class=\"media-heading\"><a href=\"{{url('/',item.slug)}}\">{{item.title}}</a></h4>
                            </div>
                        </div>
                    </div><!--/.col-md-4-->
                {% endfor %}
                </div>
            </div><!--/.row-->
        </div><!--/.container-->", "/home/vagrant/Code/octoCMS/themes/multi/partials/services2.htm", "");
    }
}
