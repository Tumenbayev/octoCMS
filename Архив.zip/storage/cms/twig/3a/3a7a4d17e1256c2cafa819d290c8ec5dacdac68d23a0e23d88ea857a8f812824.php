<?php

/* /home/vagrant/Code/octoCMS/themes/multi/partials/video.htm */
class __TwigTemplate_959fad04cf69f0b76f4396d1d985a39ff175c4ba9febeb308f30cab7bf330e61 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"homepage-hero-module\">
    <div class=\"video-container\">
        <div class=\"filter\"></div>
        <video autoplay loop class=\"fillWidth\">
            <source src=\"/storage/app/media/videos/1.mp4\" type=\"video/mp4\" />Your browser does not support the video tag. I suggest you upgrade your browser.
            <source src=\"/storage/app/media/videos/1.webm\" type=\"video/webm\" />Your browser does not support the video tag. I suggest you upgrade your browser.
        </video>
        <div class=\"poster hidden\">
            <img src=\"/storage/app/media/videos/1.jpg\" alt=\"\">
        </div>
        <div class=\"poster-caption\">
            <a href=\"#cta\"><h2>Что внизу?</h2></a>
        </div>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "/home/vagrant/Code/octoCMS/themes/multi/partials/video.htm";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"homepage-hero-module\">
    <div class=\"video-container\">
        <div class=\"filter\"></div>
        <video autoplay loop class=\"fillWidth\">
            <source src=\"/storage/app/media/videos/1.mp4\" type=\"video/mp4\" />Your browser does not support the video tag. I suggest you upgrade your browser.
            <source src=\"/storage/app/media/videos/1.webm\" type=\"video/webm\" />Your browser does not support the video tag. I suggest you upgrade your browser.
        </video>
        <div class=\"poster hidden\">
            <img src=\"/storage/app/media/videos/1.jpg\" alt=\"\">
        </div>
        <div class=\"poster-caption\">
            <a href=\"#cta\"><h2>Что внизу?</h2></a>
        </div>
    </div>
</div>", "/home/vagrant/Code/octoCMS/themes/multi/partials/video.htm", "");
    }
}
