<?php

/* /home/vagrant/Code/octoCMS/themes/multi/partials/map.htm */
class __TwigTemplate_85125645e782cd77989e3aeaaf3f7f9cad12c9f5bb8f3aeb41c9e701fa7b894a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<a class=\"dg-widget-link\" href=\"http://2gis.kz/uralsk/firm/70000001024986471/center/51.404703,51.223748/zoom/16?utm_medium=widget-source&utm_campaign=firmsonmap&utm_source=bigMap\">Посмотреть на карте Уральска</a><div class=\"dg-widget-link\"><a href=\"http://2gis.kz/uralsk/center/51.404703,51.223748/zoom/16/routeTab/rsType/bus/to/51.404703,51.223748╎BEAUTYMED, клиника дерматокосметологии?utm_medium=widget-source&utm_campaign=firmsonmap&utm_source=route\">Найти проезд до BEAUTYMED, клиника дерматокосметологии</a></div><script charset=\"utf-8\" src=\"http://widgets.2gis.com/js/DGWidgetLoader.js\"></script><script charset=\"utf-8\">new DGWidgetLoader({\"width\":100+'%',\"height\":400,\"borderColor\":\"#a3a3a3\",\"pos\":{\"lat\":51.223748,\"lon\":51.404703,\"zoom\":16},\"opt\":{\"city\":\"uralsk\"},\"org\":[{\"id\":\"70000001024986471\"}]});</script><noscript style=\"color:#c00;font-size:16px;font-weight:bold;\">Виджет карты использует JavaScript. Включите его в настройках вашего браузера.</noscript>";
    }

    public function getTemplateName()
    {
        return "/home/vagrant/Code/octoCMS/themes/multi/partials/map.htm";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<a class=\"dg-widget-link\" href=\"http://2gis.kz/uralsk/firm/70000001024986471/center/51.404703,51.223748/zoom/16?utm_medium=widget-source&utm_campaign=firmsonmap&utm_source=bigMap\">Посмотреть на карте Уральска</a><div class=\"dg-widget-link\"><a href=\"http://2gis.kz/uralsk/center/51.404703,51.223748/zoom/16/routeTab/rsType/bus/to/51.404703,51.223748╎BEAUTYMED, клиника дерматокосметологии?utm_medium=widget-source&utm_campaign=firmsonmap&utm_source=route\">Найти проезд до BEAUTYMED, клиника дерматокосметологии</a></div><script charset=\"utf-8\" src=\"http://widgets.2gis.com/js/DGWidgetLoader.js\"></script><script charset=\"utf-8\">new DGWidgetLoader({\"width\":100+'%',\"height\":400,\"borderColor\":\"#a3a3a3\",\"pos\":{\"lat\":51.223748,\"lon\":51.404703,\"zoom\":16},\"opt\":{\"city\":\"uralsk\"},\"org\":[{\"id\":\"70000001024986471\"}]});</script><noscript style=\"color:#c00;font-size:16px;font-weight:bold;\">Виджет карты использует JavaScript. Включите его в настройках вашего браузера.</noscript>", "/home/vagrant/Code/octoCMS/themes/multi/partials/map.htm", "");
    }
}
