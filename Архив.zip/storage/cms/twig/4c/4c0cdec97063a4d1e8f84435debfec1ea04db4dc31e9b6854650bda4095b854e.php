<?php

/* /home/vagrant/Code/octoCMS/themes/multi/partials/nav.htm */
class __TwigTemplate_aa46794321d77f4fd86e438573427b668985cd78b9f2424360f5eefb69f1021a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<nav id=\"main-menu\" class=\"navbar navbar-default navbar-fixed-top\" role=\"banner\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"sr-only\">Toggle navigation</span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                    <a class=\"navbar-brand\" href=\"";
        // line 10
        echo url("/");
        echo "\"><img src=\"";
        echo $this->env->getExtension('Cms\Twig\Extension')->themeFilter("assets/images/logo.png");
        echo "\" alt=\"logo\" id=\"logo\"/></a>
                </div>

                <div class=\"collapse navbar-collapse navbar-right\">
                    <ul class=\"nav navbar-nav\">
                        <li class=\"scroll active\"><a href=\"";
        // line 15
        echo url("/");
        echo "\">Главная</a></li>
                        <li><a href=\"";
        // line 16
        echo url("uslugi");
        echo "\">Услуги</a></li>
                        <li><a href=\"";
        // line 17
        echo url("otzyvy");
        echo "\">Отзывы</a></li>
                        <li class=\"scroll\"><a href=\"";
        // line 18
        echo url("/");
        echo "#portfolio\">Сертификаты</a></li>
                        <li class=\"scroll\"><a href=\"";
        // line 19
        echo url("/");
        echo "#map\">Контакты</a></li>
                        <li><a href=\"";
        // line 20
        echo url("beautyspa");
        echo "\" style=\"color:#836fe0\"><strong>Beauty&Spa</strong></a></li>
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->";
    }

    public function getTemplateName()
    {
        return "/home/vagrant/Code/octoCMS/themes/multi/partials/nav.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 20,  56 => 19,  52 => 18,  48 => 17,  44 => 16,  40 => 15,  30 => 10,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<nav id=\"main-menu\" class=\"navbar navbar-default navbar-fixed-top\" role=\"banner\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"sr-only\">Toggle navigation</span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                    <a class=\"navbar-brand\" href=\"{{url('/')}}\"><img src=\"{{ 'assets/images/logo.png'|theme }}\" alt=\"logo\" id=\"logo\"/></a>
                </div>

                <div class=\"collapse navbar-collapse navbar-right\">
                    <ul class=\"nav navbar-nav\">
                        <li class=\"scroll active\"><a href=\"{{url('/')}}\">Главная</a></li>
                        <li><a href=\"{{url('uslugi')}}\">Услуги</a></li>
                        <li><a href=\"{{url('otzyvy')}}\">Отзывы</a></li>
                        <li class=\"scroll\"><a href=\"{{url('/')}}#portfolio\">Сертификаты</a></li>
                        <li class=\"scroll\"><a href=\"{{url('/')}}#map\">Контакты</a></li>
                        <li><a href=\"{{url('beautyspa')}}\" style=\"color:#836fe0\"><strong>Beauty&Spa</strong></a></li>
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->", "/home/vagrant/Code/octoCMS/themes/multi/partials/nav.htm", "");
    }
}
