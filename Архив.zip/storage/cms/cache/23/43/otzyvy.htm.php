<?php 
class Cms589f5e2b0cf56200320896_4173157614Class extends \Cms\Classes\LayoutCode
{

}
