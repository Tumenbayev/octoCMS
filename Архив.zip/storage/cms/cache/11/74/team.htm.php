<?php 
class Cms589f20cb034a4822793622_2446839119Class extends \Cms\Classes\PartialCode
{

}
