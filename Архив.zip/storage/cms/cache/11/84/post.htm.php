<?php 
class Cms589f20ca4bd22083394987_882302313Class extends \Cms\Classes\LayoutCode
{

}
