<?php 
class Cms589f5108d5aef690575286_1587118788Class extends \Cms\Classes\PartialCode
{

}
