<?php 
class Cms58a5f7c2a85e0681868081_2812576769Class extends \Cms\Classes\LayoutCode
{

}
