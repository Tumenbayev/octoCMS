<?php 
class Cms589f20ca98090305545723_1149559266Class extends \Cms\Classes\PartialCode
{

}
