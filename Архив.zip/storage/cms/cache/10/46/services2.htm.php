<?php 
class Cms589f20cae4bc6609715903_3001549796Class extends \Cms\Classes\PartialCode
{

}
