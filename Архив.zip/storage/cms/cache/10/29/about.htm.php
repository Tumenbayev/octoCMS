<?php 
class Cms589f1f80648fe938235628_96273086Class extends \Cms\Classes\PartialCode
{

}
