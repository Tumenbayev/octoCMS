<?php 
class Cms589f1f7ee6c0f706813553_2793016549Class extends \Cms\Classes\PageCode
{
public function onStart(){
        $this['certs'] = glob('storage/app/media/legacy/*.{jpg,gif,png}', GLOB_BRACE);
}
public function onEmailSend(){
	$values = post();
	if(!empty($values['name']) && !empty($values['phoneNum']))
	{
		$params = ['name' => $values['name'], 'phoneNum' => $values['phoneNum']];
		Mail::sendTo('adilbek.tumenbayev@gmail.com', 'mailTemplate', $params);
		return ['#result' => '<div class="alert alert-success">Ваш запрос на звонок принят, ожидайте звонка от нашего оператора!</div>'];
	}
	else
	{
		return ['#result' => '<div class="alert alert-warning">Заполните все поля!</div>'];
	}
}
}
