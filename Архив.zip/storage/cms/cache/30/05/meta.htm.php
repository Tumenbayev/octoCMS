<?php 
class Cms589f1f7f6c61d023237671_3322542228Class extends \Cms\Classes\PartialCode
{

}
