<?php 
class Cms589f22258145d962947270_2486146227Class extends \Cms\Classes\PartialCode
{

}
