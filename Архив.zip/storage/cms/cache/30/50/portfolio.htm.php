<?php 
class Cms589f1f804ed9a150663558_2617797451Class extends \Cms\Classes\PartialCode
{

}
