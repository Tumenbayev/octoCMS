<?php 
use Faq\Faq\Models\Faq;
class Cms589f5f0ccda83925892070_4016145781Class extends \Cms\Classes\PageCode
{
public function onCommentAdd() {
	$values = post();
	if (!empty($values['name']) && !empty($values['text'])) {
		$model = new Faq();
		$model->name = $values['name'];
		$model->email = $values['email'];
		$model->comment = $values['text'];
		$model->save();
		$this['result'] = 'Ваш комментарий успешно сохранен!';
	}
	else {
		$this['result'] = 'Заполните поля имя и соообщение!';
	}
	return $this['result'];
}
}
