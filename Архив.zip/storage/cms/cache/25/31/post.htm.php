<?php 
use Post\Post\Components\Post;
class Cms589f20ca53da8017112461_2591630967Class extends \Cms\Classes\PageCode
{
public function onStart()
{
  $this['post'] = Post::getPostBySlug($this->param('slug'));
  if(Post::getPostBySlug($this->param('slug'))==null){
    return \Response::make('К сожалению такой страницы не существует, вернемся обратно на <a href="/">главную</a>?', 404);
  }
}
}
