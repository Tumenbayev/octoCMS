<?php 
class Cms58a5f7a73e445823446720_3195248214Class extends \Cms\Classes\LayoutCode
{

}
