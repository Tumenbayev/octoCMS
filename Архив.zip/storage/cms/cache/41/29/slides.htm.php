<?php 
class Cms589f20c0bf531776240141_1997645092Class extends \Cms\Classes\PartialCode
{

}
