<?php 
class Cms589f5f0d3c799983799632_139931875Class extends \Cms\Classes\PartialCode
{

}
