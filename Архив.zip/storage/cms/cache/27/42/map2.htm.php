<?php 
class Cms589f20cb366b3260711866_1190383336Class extends \Cms\Classes\PartialCode
{

}
