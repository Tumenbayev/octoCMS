<?php 
class Cms589f1f809105c866266847_2858954341Class extends \Cms\Classes\PartialCode
{

}
