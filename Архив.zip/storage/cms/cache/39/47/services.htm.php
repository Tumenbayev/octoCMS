<?php 
class Cms589f1f8037521884055901_537360064Class extends \Cms\Classes\PartialCode
{

}
