<?php 
class Cms589f1f80ce009402819875_3854118198Class extends \Cms\Classes\PartialCode
{

}
