<?php 
class Cms58a5ee62a5c1b937648083_4202466607Class extends \Cms\Classes\PartialCode
{

}
