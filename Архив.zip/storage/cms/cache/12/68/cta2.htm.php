<?php 
class Cms589f20cb1f9ee983222036_881406374Class extends \Cms\Classes\PartialCode
{

}
