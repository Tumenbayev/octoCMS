<?php 
class Cms589f1f80bf0a9820847732_3807349863Class extends \Cms\Classes\PartialCode
{

}
