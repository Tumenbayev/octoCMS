<?php 
class Cms589f20cacc519533633899_3101658667Class extends \Cms\Classes\PartialCode
{

}
