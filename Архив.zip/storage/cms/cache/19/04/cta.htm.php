<?php 
class Cms589f1f8028709928752132_1038757449Class extends \Cms\Classes\PartialCode
{

}
