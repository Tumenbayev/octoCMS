<?php

/* /home/vagrant/Code/octoCMS/themes/multi/partials/pricing.htm */
class __TwigTemplate_a47748f3420016822ac7a5ffc58733efb5b7c65e76b9db5521d8dc42ea6fba08 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"container\">
            <div class=\"section-header\">
                <h2 class=\"section-title text-center wow fadeInDown\">Pricing Table</h2>
                <p class=\"text-center wow fadeInDown\">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut <br> et dolore magna aliqua. Ut enim ad minim veniam</p>
            </div>

            <div class=\"row\">
                <div class=\"col-sm-6 col-md-3\">
                    <div class=\"wow zoomIn\" data-wow-duration=\"400ms\" data-wow-delay=\"0ms\">
                        <ul class=\"pricing\">
                            <li class=\"plan-header\">
                                <div class=\"price-duration\">
                                    <span class=\"price\">
                                        \$39
                                    </span>
                                    <span class=\"duration\">
                                        per month
                                    </span>
                                </div>

                                <div class=\"plan-name\">
                                    Starter
                                </div>
                            </li>
                            <li><strong>1</strong> DOMAIN</li>
                            <li><strong>100GB</strong> DISK SPACE</li>
                            <li><strong>UNLIMITED</strong> BANDWIDTH</li>
                            <li>SHARED SSL CERTIFICATE</li>
                            <li><strong>10</strong> EMAIL ADDRESS</li>
                            <li><strong>24/7</strong> SUPPORT</li>
                            <li class=\"plan-purchase\"><a class=\"btn btn-primary\" href=\"#\">ORDER NOW</a></li>
                        </ul>
                    </div>
                </div>
                <div class=\"col-sm-6 col-md-3\">
                    <div class=\"wow zoomIn\" data-wow-duration=\"400ms\" data-wow-delay=\"200ms\">
                        <ul class=\"pricing featured\">
                            <li class=\"plan-header\">
                                <div class=\"price-duration\">
                                    <span class=\"price\">
                                        \$69
                                    </span>
                                    <span class=\"duration\">
                                        per month
                                    </span>
                                </div>

                                <div class=\"plan-name\">
                                    Business
                                </div>
                            </li>
                            <li><strong>3</strong> DOMAINS</li>
                            <li><strong>300GB</strong> DISK SPACE</li>
                            <li><strong>UNLIMITED</strong> BANDWIDTH</li>
                            <li>SHARED SSL CERTIFICATE</li>
                            <li><strong>30</strong> EMAIL ADDRESSES</li>
                            <li><strong>24/7</strong> SUPPORT</li>
                            <li class=\"plan-purchase\"><a class=\"btn btn-default\" href=\"#\">ORDER NOW</a></li>
                        </ul>
                    </div>
                </div>
                <div class=\"col-sm-6 col-md-3\">
                    <div class=\"wow zoomIn\" data-wow-duration=\"400ms\" data-wow-delay=\"400ms\">
                        <ul class=\"pricing\">
                            <li class=\"plan-header\">
                                <div class=\"price-duration\">
                                    <span class=\"price\">
                                        \$99
                                    </span>
                                    <span class=\"duration\">
                                        per month
                                    </span>
                                </div>

                                <div class=\"plan-name\">
                                    Pro
                                </div>
                            </li>
                            <li><strong>5</strong> DOMAINS</li>
                            <li><strong>500GB</strong> DISK SPACE</li>
                            <li><strong>UNLIMITED</strong> BANDWIDTH</li>
                            <li>SHARED SSL CERTIFICATE</li>
                            <li><strong>50</strong> EMAIL ADDRESSES</li>
                            <li><strong>24/7</strong> SUPPORT</li>
                            <li class=\"plan-purchase\"><a class=\"btn btn-primary\" href=\"#\">ORDER NOW</a></li>
                        </ul>
                    </div>
                </div>
                <div class=\"col-sm-6 col-md-3\">
                    <div class=\"wow zoomIn\" data-wow-duration=\"400ms\" data-wow-delay=\"600ms\">
                        <ul class=\"pricing\">
                            <li class=\"plan-header\">
                                <div class=\"price-duration\">
                                    <span class=\"price\">
                                        \$199
                                    </span>
                                    <span class=\"duration\">
                                        per month
                                    </span>
                                </div>

                                <div class=\"plan-name\">
                                    Ultra
                                </div>
                            </li>
                            <li><strong>10</strong> DOMAINS</li>
                            <li><strong>1000GB</strong> DISK SPACE</li>
                            <li><strong>UNLIMITED</strong> BANDWIDTH</li>
                            <li>SHARED SSL CERTIFICATE</li>
                            <li><strong>100</strong> EMAIL ADDRESSES</li>
                            <li><strong>24/7</strong> SUPPORT</li>
                            <li class=\"plan-purchase\"><a class=\"btn btn-primary\" href=\"#\">ORDER NOW</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>";
    }

    public function getTemplateName()
    {
        return "/home/vagrant/Code/octoCMS/themes/multi/partials/pricing.htm";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"container\">
            <div class=\"section-header\">
                <h2 class=\"section-title text-center wow fadeInDown\">Pricing Table</h2>
                <p class=\"text-center wow fadeInDown\">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut <br> et dolore magna aliqua. Ut enim ad minim veniam</p>
            </div>

            <div class=\"row\">
                <div class=\"col-sm-6 col-md-3\">
                    <div class=\"wow zoomIn\" data-wow-duration=\"400ms\" data-wow-delay=\"0ms\">
                        <ul class=\"pricing\">
                            <li class=\"plan-header\">
                                <div class=\"price-duration\">
                                    <span class=\"price\">
                                        \$39
                                    </span>
                                    <span class=\"duration\">
                                        per month
                                    </span>
                                </div>

                                <div class=\"plan-name\">
                                    Starter
                                </div>
                            </li>
                            <li><strong>1</strong> DOMAIN</li>
                            <li><strong>100GB</strong> DISK SPACE</li>
                            <li><strong>UNLIMITED</strong> BANDWIDTH</li>
                            <li>SHARED SSL CERTIFICATE</li>
                            <li><strong>10</strong> EMAIL ADDRESS</li>
                            <li><strong>24/7</strong> SUPPORT</li>
                            <li class=\"plan-purchase\"><a class=\"btn btn-primary\" href=\"#\">ORDER NOW</a></li>
                        </ul>
                    </div>
                </div>
                <div class=\"col-sm-6 col-md-3\">
                    <div class=\"wow zoomIn\" data-wow-duration=\"400ms\" data-wow-delay=\"200ms\">
                        <ul class=\"pricing featured\">
                            <li class=\"plan-header\">
                                <div class=\"price-duration\">
                                    <span class=\"price\">
                                        \$69
                                    </span>
                                    <span class=\"duration\">
                                        per month
                                    </span>
                                </div>

                                <div class=\"plan-name\">
                                    Business
                                </div>
                            </li>
                            <li><strong>3</strong> DOMAINS</li>
                            <li><strong>300GB</strong> DISK SPACE</li>
                            <li><strong>UNLIMITED</strong> BANDWIDTH</li>
                            <li>SHARED SSL CERTIFICATE</li>
                            <li><strong>30</strong> EMAIL ADDRESSES</li>
                            <li><strong>24/7</strong> SUPPORT</li>
                            <li class=\"plan-purchase\"><a class=\"btn btn-default\" href=\"#\">ORDER NOW</a></li>
                        </ul>
                    </div>
                </div>
                <div class=\"col-sm-6 col-md-3\">
                    <div class=\"wow zoomIn\" data-wow-duration=\"400ms\" data-wow-delay=\"400ms\">
                        <ul class=\"pricing\">
                            <li class=\"plan-header\">
                                <div class=\"price-duration\">
                                    <span class=\"price\">
                                        \$99
                                    </span>
                                    <span class=\"duration\">
                                        per month
                                    </span>
                                </div>

                                <div class=\"plan-name\">
                                    Pro
                                </div>
                            </li>
                            <li><strong>5</strong> DOMAINS</li>
                            <li><strong>500GB</strong> DISK SPACE</li>
                            <li><strong>UNLIMITED</strong> BANDWIDTH</li>
                            <li>SHARED SSL CERTIFICATE</li>
                            <li><strong>50</strong> EMAIL ADDRESSES</li>
                            <li><strong>24/7</strong> SUPPORT</li>
                            <li class=\"plan-purchase\"><a class=\"btn btn-primary\" href=\"#\">ORDER NOW</a></li>
                        </ul>
                    </div>
                </div>
                <div class=\"col-sm-6 col-md-3\">
                    <div class=\"wow zoomIn\" data-wow-duration=\"400ms\" data-wow-delay=\"600ms\">
                        <ul class=\"pricing\">
                            <li class=\"plan-header\">
                                <div class=\"price-duration\">
                                    <span class=\"price\">
                                        \$199
                                    </span>
                                    <span class=\"duration\">
                                        per month
                                    </span>
                                </div>

                                <div class=\"plan-name\">
                                    Ultra
                                </div>
                            </li>
                            <li><strong>10</strong> DOMAINS</li>
                            <li><strong>1000GB</strong> DISK SPACE</li>
                            <li><strong>UNLIMITED</strong> BANDWIDTH</li>
                            <li>SHARED SSL CERTIFICATE</li>
                            <li><strong>100</strong> EMAIL ADDRESSES</li>
                            <li><strong>24/7</strong> SUPPORT</li>
                            <li class=\"plan-purchase\"><a class=\"btn btn-primary\" href=\"#\">ORDER NOW</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>", "/home/vagrant/Code/octoCMS/themes/multi/partials/pricing.htm", "");
    }
}
