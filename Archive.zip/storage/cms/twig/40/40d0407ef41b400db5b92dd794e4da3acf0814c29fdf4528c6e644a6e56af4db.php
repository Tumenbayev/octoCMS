<?php

/* /home/vagrant/Code/octoCMS/themes/multi/partials/news.htm */
class __TwigTemplate_14ff0a5ad043d28a5811663f5e9ac054972907f02d0fe2a63e4d2132536fdef3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"container\">
    <div class=\"section-header\">
        <h2 class=\"section-title text-center wow fadeInDown\">Статьи</h2>
        <p class=\"text-center wow fadeInDown\">Список последних статьей</p>
    </div>

    <div class=\"row\">
        ";
        // line 8
        if ($this->getAttribute(($context["news"] ?? null), "getBignews", array())) {
            // line 9
            echo "        <div class=\"col-sm-6\">
          <div class=\"blog-post blog-large wow fadeInLeft\" data-wow-duration=\"300ms\" data-wow-delay=\"0ms\">
                <article>
                  <header class=\"entry-header\">
                      <div class=\"entry-thumbnail\">
                          <img class=\"img-responsive\" src=\"";
            // line 14
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute(($context["news"] ?? null), "getBigNews", array()), "attachments", array()), 0, array(), "array"), "path", array()), "html", null, true);
            echo "\" alt=\"\">
                      </div>
                      <div class=\"entry-date\">";
            // line 16
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute(($context["news"] ?? null), "getBigNews", array()), "created_at", array()), "j F Y"), "html", null, true);
            echo "</div>
                      <h2 class=\"entry-title\"><a href=\"";
            // line 17
            echo url("article", $this->getAttribute($this->getAttribute(($context["news"] ?? null), "getBignews", array()), "slug", array()));
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["news"] ?? null), "getBigNews", array()), "title", array()), "html", null, true);
            echo "</a></h2>
                  </header>

                  <div class=\"entry-content\">
                      <P>";
            // line 21
            echo call_user_func_array($this->env->getFunction('str_limit')->getCallable(), array("limit", $this->getAttribute($this->getAttribute(($context["news"] ?? null), "getBigNews", array()), "description", array()), 20));
            echo "</P>
                      <a class=\"btn btn-primary\" href=\"";
            // line 22
            echo url("article", $this->getAttribute($this->getAttribute(($context["news"] ?? null), "getBignews", array()), "slug", array()));
            echo "\">Читать далее</a>
                  </div>
                </article>
            </div>
          </div>
         ";
        }
        // line 28
        echo "          <div class=\"col-sm-6\">
          ";
        // line 29
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["news"] ?? null), "getNews", array()));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            echo " <!--Вызывем метод getPosts в нашем компоненте и проходимся циклом по полученынм запиям!-->
          ";
            // line 30
            if ($this->getAttribute($context["loop"], "first", array())) {
                // line 31
                echo "          <!-- НИЧЕГО -->
          ";
            } else {
                // line 33
                echo "            <div class=\"blog-post blog-media wow fadeInRight\" data-wow-duration=\"300ms\" data-wow-delay=\"0ms\">
                <article class=\"media clearfix\">
                  <header class=\"entry-header\">
                      <div class=\"entry-thumbnail\">
                          <img class=\"img-responsive\" src=\"";
                // line 37
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute($context["item"], "attachments", array()), 0, array(), "array"), "path", array()), "html", null, true);
                echo "\" alt=\"\">
                      </div>
                      <div class=\"entry-date\">";
                // line 39
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["item"], "created_at", array()), "j F Y"), "html", null, true);
                echo "</div>
                      <h2 class=\"entry-title\"><a href=\"";
                // line 40
                echo url("article", $this->getAttribute($context["item"], "slug", array()));
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "title", array()), "html", null, true);
                echo "</a></h2>
                  </header>

                  <div class=\"entry-content\">
                      <P>";
                // line 44
                echo call_user_func_array($this->env->getFunction('str_limit')->getCallable(), array("limit", $this->getAttribute($context["item"], "description", array()), 10));
                echo "</P>
                      <a class=\"btn btn-primary\" href=\"";
                // line 45
                echo url("article", $this->getAttribute($context["item"], "slug", array()));
                echo "\">Читать далее</a>
                  </div>
                </article>
            </div>
      ";
            }
            // line 50
            echo "      ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 51
        echo "      </div>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "/home/vagrant/Code/octoCMS/themes/multi/partials/news.htm";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  146 => 51,  132 => 50,  124 => 45,  120 => 44,  111 => 40,  107 => 39,  102 => 37,  96 => 33,  92 => 31,  90 => 30,  71 => 29,  68 => 28,  59 => 22,  55 => 21,  46 => 17,  42 => 16,  37 => 14,  30 => 9,  28 => 8,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"container\">
    <div class=\"section-header\">
        <h2 class=\"section-title text-center wow fadeInDown\">Статьи</h2>
        <p class=\"text-center wow fadeInDown\">Список последних статьей</p>
    </div>

    <div class=\"row\">
        {% if news.getBignews %}
        <div class=\"col-sm-6\">
          <div class=\"blog-post blog-large wow fadeInLeft\" data-wow-duration=\"300ms\" data-wow-delay=\"0ms\">
                <article>
                  <header class=\"entry-header\">
                      <div class=\"entry-thumbnail\">
                          <img class=\"img-responsive\" src=\"{{ news.getBigNews.attachments[0].path }}\" alt=\"\">
                      </div>
                      <div class=\"entry-date\">{{ news.getBigNews.created_at | date('j F Y') }}</div>
                      <h2 class=\"entry-title\"><a href=\"{{url('article',news.getBignews.slug)}}\">{{ news.getBigNews.title }}</a></h2>
                  </header>

                  <div class=\"entry-content\">
                      <P>{{ str_limit(news.getBigNews.description, 20) |raw }}</P>
                      <a class=\"btn btn-primary\" href=\"{{url('article',news.getBignews.slug)}}\">Читать далее</a>
                  </div>
                </article>
            </div>
          </div>
         {% endif %}
          <div class=\"col-sm-6\">
          {% for item in news.getNews %} <!--Вызывем метод getPosts в нашем компоненте и проходимся циклом по полученынм запиям!-->
          {% if loop.first %}
          <!-- НИЧЕГО -->
          {% else %}
            <div class=\"blog-post blog-media wow fadeInRight\" data-wow-duration=\"300ms\" data-wow-delay=\"0ms\">
                <article class=\"media clearfix\">
                  <header class=\"entry-header\">
                      <div class=\"entry-thumbnail\">
                          <img class=\"img-responsive\" src=\"{{ item.attachments[0].path }}\" alt=\"\">
                      </div>
                      <div class=\"entry-date\">{{ item.created_at |date('j F Y') }}</div>
                      <h2 class=\"entry-title\"><a href=\"{{url('article',item.slug)}}\">{{ item.title }}</a></h2>
                  </header>

                  <div class=\"entry-content\">
                      <P>{{ str_limit(item.description, 10)|raw }}</P>
                      <a class=\"btn btn-primary\" href=\"{{url('article',item.slug)}}\">Читать далее</a>
                  </div>
                </article>
            </div>
      {% endif %}
      {% endfor %}
      </div>
    </div>
</div>", "/home/vagrant/Code/octoCMS/themes/multi/partials/news.htm", "");
    }
}
