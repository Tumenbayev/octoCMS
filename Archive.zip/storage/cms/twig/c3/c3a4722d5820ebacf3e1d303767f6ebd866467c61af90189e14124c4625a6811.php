<?php

/* /home/vagrant/Code/octoCMS/themes/multi/pages/post.htm */
class __TwigTemplate_609ea1274658c08a02ecf35671670414a35a2a60a364f82cbe700fdd7742f191 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "/home/vagrant/Code/octoCMS/themes/multi/pages/post.htm";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "/home/vagrant/Code/octoCMS/themes/multi/pages/post.htm", "");
    }
}
