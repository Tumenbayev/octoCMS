<?php 
class Cms58875608d578d881037294_831197247Class extends \Cms\Classes\PartialCode
{

}
