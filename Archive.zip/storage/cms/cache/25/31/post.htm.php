<?php 
use Post\Post\Components\Post;
class Cms58878161d61a0265787380_1472542434Class extends \Cms\Classes\PageCode
{
public function onStart()
{
  $this['post'] = Post::getPostBySlug($this->param('slug'));
}
}
