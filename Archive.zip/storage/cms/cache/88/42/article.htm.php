<?php 
class Cms588779ece4cd1301653089_2947615872Class extends \Cms\Classes\LayoutCode
{

}
