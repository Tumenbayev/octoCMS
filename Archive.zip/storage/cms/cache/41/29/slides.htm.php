<?php 
class Cms58876002c52d7551268370_4035052993Class extends \Cms\Classes\PartialCode
{

}
