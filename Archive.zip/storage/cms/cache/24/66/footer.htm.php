<?php 
class Cms58874d8a4a78d040761882_4216349503Class extends \Cms\Classes\PartialCode
{

}
