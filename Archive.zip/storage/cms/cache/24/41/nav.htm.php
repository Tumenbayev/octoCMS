<?php 
class Cms58879c0a4947d597627840_2772760665Class extends \Cms\Classes\PartialCode
{

}
