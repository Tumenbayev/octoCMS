<?php 
class Cms58879c09d2860525734309_763076832Class extends \Cms\Classes\LayoutCode
{

}
