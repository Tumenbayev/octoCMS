<?php 
class Cms5887855c37c45861292388_1536336666Class extends \Cms\Classes\PageCode
{

}
