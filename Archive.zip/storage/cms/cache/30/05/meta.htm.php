<?php 
class Cms58874d892bef4357945795_632295517Class extends \Cms\Classes\PartialCode
{

}
