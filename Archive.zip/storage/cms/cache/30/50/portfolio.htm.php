<?php 
class Cms58874d89b80fd714989074_2220345904Class extends \Cms\Classes\PartialCode
{

}
