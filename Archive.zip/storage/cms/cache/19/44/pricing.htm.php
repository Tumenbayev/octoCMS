<?php 
class Cms58874d8a0f314767856525_2556712240Class extends \Cms\Classes\PartialCode
{

}
