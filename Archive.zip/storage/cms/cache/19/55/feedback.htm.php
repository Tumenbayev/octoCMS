<?php 
class Cms58874d8a1ca11289147993_3962322994Class extends \Cms\Classes\PartialCode
{

}
