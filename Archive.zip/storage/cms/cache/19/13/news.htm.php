<?php 
class Cms58874d9a84e53238605541_3421949444Class extends \Cms\Classes\PageCode
{

}
