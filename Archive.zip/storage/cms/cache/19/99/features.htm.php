<?php 
class Cms58874d89909a0699172760_1045532923Class extends \Cms\Classes\PartialCode
{

}
