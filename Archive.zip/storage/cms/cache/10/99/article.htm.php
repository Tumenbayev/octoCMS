<?php 
use Adilbek\News\Components\News;
class Cms58878115deb1b995632020_654689336Class extends \Cms\Classes\PageCode
{
public function onStart()
{
  $this['article'] = News::getNewsBySlug($this->param('slug'));
}
}
