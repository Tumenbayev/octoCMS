<?php 
class Cms58879b50b8a50717407481_3246314571Class extends \Cms\Classes\PartialCode
{

}
