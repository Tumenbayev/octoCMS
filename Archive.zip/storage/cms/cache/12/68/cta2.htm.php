<?php 
class Cms58874d899d726174295094_2063118805Class extends \Cms\Classes\PartialCode
{

}
