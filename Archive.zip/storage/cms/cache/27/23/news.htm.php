<?php 
class Cms58874d9a7e631499498525_180629785Class extends \Cms\Classes\LayoutCode
{

}
