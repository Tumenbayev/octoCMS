<?php 
class Cms58877915c774a169813179_180851156Class extends \Cms\Classes\PartialCode
{

}
