<?php 
class Cms5887820d1bbd8687368415_2548552499Class extends \Cms\Classes\LayoutCode
{

}
