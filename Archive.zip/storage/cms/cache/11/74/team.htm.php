<?php 
class Cms58874d89e1814031060082_1367681026Class extends \Cms\Classes\PartialCode
{

}
