<?php 
class Cms58874d8a2a331249455532_3997187378Class extends \Cms\Classes\PartialCode
{

}
