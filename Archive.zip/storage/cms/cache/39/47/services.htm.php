<?php 
class Cms5887911db70db256464621_418522110Class extends \Cms\Classes\PartialCode
{

}
